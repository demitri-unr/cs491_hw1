defmodule Cs491Hw1Web.PageViewTest do
  use Cs491Hw1Web.ConnCase, async: true
end
