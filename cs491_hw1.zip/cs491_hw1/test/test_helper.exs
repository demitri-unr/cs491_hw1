ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(Cs491Hw1.Repo, :manual)
