defmodule Cs491Hw1.Mailer do
  use Swoosh.Mailer, otp_app: :cs491_hw1
end
