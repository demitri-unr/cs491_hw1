defmodule Cs491Hw1.Repo do
  use Ecto.Repo,
    otp_app: :cs491_hw1,
    adapter: Ecto.Adapters.Postgres
end
