defmodule Cs491Hw1.OfficeAssets.Computer do
  use Ecto.Schema
  import Ecto.Changeset

  schema "computers" do
    field :brand, :string
    field :operating_system, :string

    timestamps()
  end

  @doc false
  def changeset(computer, attrs) do
    computer
    |> cast(attrs, [:brand, :operating_system])
    |> validate_required([:brand, :operating_system])
  end
end
