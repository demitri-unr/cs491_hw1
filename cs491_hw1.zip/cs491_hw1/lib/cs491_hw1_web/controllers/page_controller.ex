defmodule Cs491Hw1Web.PageController do
  use Cs491Hw1Web, :controller

  def index(conn, _params) do
    render(conn, "index.html")
  end
end
