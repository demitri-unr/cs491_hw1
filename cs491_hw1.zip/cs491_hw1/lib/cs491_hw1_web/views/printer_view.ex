defmodule Cs491Hw1Web.PrinterView do
  use Cs491Hw1Web, :view
end
