defmodule Cs491Hw1Web.ComputerView do
  use Cs491Hw1Web, :view
end
