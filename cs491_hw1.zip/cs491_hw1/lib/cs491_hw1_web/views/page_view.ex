defmodule Cs491Hw1Web.PageView do
  use Cs491Hw1Web, :view
end
