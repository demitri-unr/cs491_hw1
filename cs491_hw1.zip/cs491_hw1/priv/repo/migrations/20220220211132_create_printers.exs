defmodule Cs491Hw1.Repo.Migrations.CreatePrinters do
  use Ecto.Migration

  def change do
    create table(:printers) do
      add :model, :string
      add :inventory_code, :integer
      add :office_number, :integer
      add :building, :string

      timestamps()
    end
  end
end
