defmodule Cs491Hw1.Repo.Migrations.CreateComputers do
  use Ecto.Migration

  def change do
    create table(:computers) do
      add :brand, :string
      add :operating_system, :string

      timestamps()
    end
  end
end
